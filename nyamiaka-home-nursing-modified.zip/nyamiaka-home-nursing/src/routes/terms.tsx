import { createFileRoute } from "@tanstack/react-router";
import { SITE } from "@/lib/site";

export const Route = createFileRoute("/terms")({
  component: TermsPage,
  head: () => ({
    meta: [
      { title: `Terms — ${SITE.businessName}` },
      {
        name: "description",
        content:
          "Terms of service for Nyamiaka Home Nursing & Care — scope of services, bookings, and limitations of home-based nursing care.",
      },
      { property: "og:title", content: `Terms — ${SITE.businessName}` },
      {
        property: "og:description",
        content: "The terms governing home nursing visits and services provided.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function TermsPage() {
  return (
    <div>
      <section className="bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <p className="section-eyebrow">Legal</p>
          <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
            Terms of Service
          </h1>
        </div>
      </section>
      <section>
        <div className="container-site max-w-3xl space-y-8 py-16 md:py-20">
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              1. Scope of services
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              {SITE.businessName} provides planned, nurse-led home-based nursing services within
              the nurse's professional scope of practice, including nursing assessment, monitoring,
              health education and appropriate nursing interventions. Services do not replace
              hospital care, physician care or emergency medical services.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              2. Not an emergency service
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              This is a planned home-visiting service and is not an emergency response service. In
              a medical emergency — including severe difficulty breathing, loss of consciousness,
              severe chest pain, uncontrolled bleeding or seizures — seek immediate emergency
              medical care.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              3. Bookings & appointments
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              Submitting a booking request is a request only. An appointment is confirmed only
              after direct communication with the nurse. Visit times and availability may be
              adjusted by mutual agreement.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              4. Referrals & limits of home care
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              Where a patient's condition requires assessment or treatment beyond what can
              appropriately be provided at home, the nurse will recommend referral to a hospital,
              clinic or other appropriate healthcare facility.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">5. Payment</h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              Fees depend on the type of care, distance and frequency of visits, and are agreed
              with you before care begins. No claim of guaranteed recovery or outcome is made.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">6. Contact</h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              Questions about these terms? Contact {SITE.founder} at{" "}
              <a href={`mailto:${SITE.email}`} className="font-medium text-primary hover:underline">
                {SITE.email}
              </a>{" "}
              or call {SITE.phoneDisplay}.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
