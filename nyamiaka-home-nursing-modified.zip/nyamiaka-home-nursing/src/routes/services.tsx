import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { CalendarCheck, ChevronDown, Siren, Stethoscope } from "lucide-react";

import homeAssessment from "@/assets/home-assessment.jpg";
import { SITE, SERVICES } from "@/lib/site";

export const Route = createFileRoute("/services")({
  component: ServicesPage,
  head: () => ({
    meta: [
      { title: `Home Nursing Services — ${SITE.businessName}` },
      {
        name: "description",
        content:
          "Home nursing visits, wound & dressing care, post-hospitalization support, vital signs monitoring, medication support, elderly and postnatal care in Nairobi, Kenya.",
      },
      { property: "og:title", content: `Home Nursing Services — ${SITE.businessName}` },
      {
        property: "og:description",
        content:
          "Professional nurse-led home nursing services in Nairobi — assessment, wound care, monitoring, education and support.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const faqs = [
  {
    q: "What is home-based nursing care?",
    a: "Home-based nursing care brings appropriate professional nursing services — assessment, monitoring, education and interventions — to you in your own home, rather than requiring you to travel to a facility.",
  },
  {
    q: "Who can benefit from home nursing?",
    a: "Patients recovering after hospitalization, older adults who need support at home, people living with chronic conditions, mothers in the postnatal period, and family caregivers who need guidance and relief.",
  },
  {
    q: "What services does Clinton provide?",
    a: "Home nursing visits, wound and dressing care, post-hospitalization support, vital signs and health monitoring, medication support within professional scope, elderly nursing support, chronic disease support, maternal and postnatal support, caregiver education and health education.",
  },
  {
    q: "How do I book a home visit?",
    a: "Call or WhatsApp 0757 669 961, or submit the booking request form on this website. Clinton will contact you to discuss your needs and confirm availability.",
  },
  {
    q: "Do you provide wound care?",
    a: "Yes. Appropriate wound assessment, dressing and monitoring is provided according to the patient's condition and care requirements.",
  },
  {
    q: "Do you provide medication administration?",
    a: "Medication-related support and administration is provided where appropriate and within professional nursing scope, alongside coordination with the patient's established medical care.",
  },
  {
    q: "Do you provide elderly nursing support?",
    a: "Yes. Professional nursing support and health monitoring is available for older adults who require assistance at home.",
  },
  {
    q: "What areas do you cover?",
    a: "Nairobi, Kenya, with surrounding areas added as the service grows. Please get in touch to confirm coverage in your location.",
  },
  {
    q: "How much does a home visit cost?",
    a: "Costs depend on the type of care required, the distance travelled and the frequency of visits. Contact Clinton to discuss your needs and receive clear pricing before any commitment.",
  },
  {
    q: "Do you provide emergency services?",
    a: "No. This is a planned home-based nursing service and is not an emergency response service. For life-threatening conditions, seek immediate emergency medical care.",
  },
];

function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="card-soft">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between gap-4 text-left"
        aria-expanded={open}
      >
        <span className="font-display text-lg font-semibold tracking-tight">{q}</span>
        <ChevronDown
          className={`size-5 shrink-0 text-primary transition-transform ${open ? "rotate-180" : ""}`}
        />
      </button>
      {open && <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">{a}</p>}
    </div>
  );
}

function ServicesPage() {
  return (
    <div>
      <section className="bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <p className="section-eyebrow">Services</p>
          <h1 className="mt-3 max-w-[26ch] font-display text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
            Home Nursing Services
          </h1>
          <p className="mt-5 max-w-[60ch] text-base leading-relaxed text-pretty text-muted-foreground md:text-lg">
            Professional nursing care, health education, monitoring and support — delivered to
            patients and families in the comfort and privacy of their homes.
          </p>
        </div>
      </section>

      <section>
        <div className="container-site grid gap-10 py-16 md:grid-cols-12 md:py-20">
          <div className="grid content-start gap-4 sm:grid-cols-2 md:col-span-7">
            {SERVICES.map((service) => (
              <div key={service.title} className="card-soft">
                <h2 className="font-display text-lg font-semibold tracking-tight">
                  {service.title}
                </h2>
                <p className="mt-2 text-sm leading-relaxed text-pretty text-muted-foreground">
                  {service.text}
                </p>
              </div>
            ))}
          </div>
          <aside className="md:col-span-5">
            <div className="sticky top-28 space-y-6">
              <img
                src={homeAssessment}
                alt="Professional nurse conducting a home-based patient assessment"
                width={1024}
                height={1024}
                loading="lazy"
                className="aspect-4/5 w-full rounded-3xl object-cover ring-1 ring-border"
              />
              <div className="rounded-2xl bg-primary px-6 py-6 text-primary-foreground">
                <Stethoscope className="size-6" />
                <h3 className="mt-3 font-display text-xl font-semibold leading-snug text-balance">
                  This is professional nurse-led care — not simply caregiving.
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-pretty text-primary-foreground/85">
                  {SITE.businessName} provides appropriate professional nursing support within the
                  home environment while recognizing when a patient requires assessment or
                  treatment at a hospital, clinic or other appropriate healthcare facility.
                </p>
              </div>
              <Link to="/book" className="btn-primary w-full">
                <CalendarCheck className="size-4" />
                Request a home visit
              </Link>
            </div>
          </aside>
        </div>
      </section>

      {/* Patient safety */}
      <section className="border-t border-border bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <div className="max-w-[52ch]">
            <p className="section-eyebrow">Patient safety</p>
            <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Patient Safety Comes First
            </h2>
          </div>
          <div className="mt-8 flex flex-wrap gap-2.5">
            {[
              "Appropriate nursing assessment",
              "Infection prevention",
              "Safe medication practices",
              "Patient identification",
              "Confidentiality",
              "Documentation",
              "Patient education",
              "Recognition of deterioration",
              "Appropriate referral",
            ].map((item) => (
              <span
                key={item}
                className="rounded-full bg-card px-4 py-2 text-sm font-medium text-foreground ring-1 ring-border"
              >
                {item}
              </span>
            ))}
          </div>
          <p className="mt-8 max-w-[70ch] text-base leading-relaxed text-pretty text-muted-foreground">
            Our goal is not simply to provide care at home. Our goal is to provide appropriate,
            safe and professional nursing care while recognizing when a patient requires a higher
            level of medical attention.
          </p>
        </div>
      </section>

      {/* Emergency notice */}
      <section>
        <div className="container-site py-16 md:py-20">
          <div className="rounded-3xl bg-destructive/10 px-6 py-10 ring-1 ring-destructive/25 md:px-12">
            <div className="flex items-start gap-4">
              <Siren className="mt-1 size-6 shrink-0 text-destructive" />
              <div>
                <h2 className="font-display text-2xl font-semibold tracking-tight text-foreground">
                  Medical Emergency?
                </h2>
                <p className="mt-3 max-w-[72ch] text-sm leading-relaxed text-pretty text-muted-foreground">
                  {SITE.businessName} provides planned home-based nursing services and is not an
                  emergency response service. For severe difficulty breathing, loss of
                  consciousness, severe chest pain, uncontrolled bleeding, seizures or other
                  potentially life-threatening conditions, seek immediate emergency medical care.
                </p>
                <a
                  href={SITE.emergencyNumberHref}
                  className="mt-5 inline-flex items-center gap-2 rounded-full bg-destructive px-6 py-3 text-sm font-semibold text-destructive-foreground transition-opacity hover:opacity-90"
                >
                  Seek Emergency Care ({SITE.emergencyNumberDisplay})
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="border-t border-border bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <div className="max-w-[52ch]">
            <p className="section-eyebrow">FAQ</p>
            <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Frequently asked questions
            </h2>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-2">
            {faqs.map((faq) => (
              <FaqItem key={faq.q} q={faq.q} a={faq.a} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
