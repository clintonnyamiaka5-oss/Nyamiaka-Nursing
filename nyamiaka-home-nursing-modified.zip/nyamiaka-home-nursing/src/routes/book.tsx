import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CalendarCheck, CheckCircle2, MessageCircle } from "lucide-react";

import { SITE, whatsappHref, SERVICES } from "@/lib/site";

export const Route = createFileRoute("/book")({
  component: BookPage,
  head: () => ({
    meta: [
      { title: `Book a Home Visit — ${SITE.businessName}` },
      {
        name: "description",
        content:
          "Request a home nursing visit in Nairobi, Kenya. Share your details and Clinton G. Nyamiaka, BScN will contact you to discuss needs and confirm availability.",
      },
      { property: "og:title", content: `Book a Home Visit — ${SITE.businessName}` },
      {
        property: "og:description",
        content:
          "Request a professional home nursing visit — nursing assessment, wound care, monitoring, elderly and postnatal support in Nairobi.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const contactMethods = ["Phone call", "WhatsApp", "Email"] as const;

function BookPage() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    patientName: "",
    contactPerson: "",
    phone: "",
    location: "",
    preferredDate: "",
    preferredTime: "",
    service: SERVICES[0].title,
    description: "",
    contactMethod: contactMethods[0],
    consent: false,
  });

  const set = (key: keyof typeof form, value: string | boolean) =>
    setForm((f) => ({ ...f, [key]: value }));

  const buildMessage = () => {
    const lines = [
      "Hello Clinton, I would like to request a home nursing visit.",
      "",
      `Patient/Client Name: ${form.patientName}`,
      `Contact Person: ${form.contactPerson || form.patientName}`,
      `Phone Number: ${form.phone}`,
      `Location: ${form.location}`,
      `Preferred Date: ${form.preferredDate}`,
      `Preferred Time: ${form.preferredTime}`,
      `Service Required: ${form.service}`,
      `Brief Description of Care Needed: ${form.description}`,
      `Preferred Contact Method: ${form.contactMethod}`,
    ];
    return lines.join("\n");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.consent) return;
    window.open(whatsappHref(buildMessage()), "_blank", "noopener");
    setSubmitted(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (submitted) {
    return (
      <section className="bg-surface-soft">
        <div className="container-site flex min-h-[60vh] items-center justify-center py-20">
          <div className="card-soft max-w-lg text-center md:p-10">
            <CheckCircle2 className="mx-auto size-12 text-primary" />
            <h1 className="mt-5 font-display text-3xl font-semibold tracking-tight text-balance">
              Thank you. Your request has been received.
            </h1>
            <p className="mt-4 text-sm leading-relaxed text-pretty text-muted-foreground md:text-base">
              {SITE.founder} will contact you to discuss your needs and confirm availability.
            </p>
            <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
              Please note: submitting this form is a request only and does not automatically
              constitute a confirmed appointment.
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <div>
      <section className="bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <p className="section-eyebrow">Book a home visit</p>
          <h1 className="mt-3 max-w-[26ch] font-display text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
            Request a Home Nursing Visit
          </h1>
          <p className="mt-5 max-w-[56ch] text-base leading-relaxed text-pretty text-muted-foreground md:text-lg">
            Share a few details about the care you need. Your request opens in WhatsApp, ready to
            send directly to Clinton.
          </p>
        </div>
      </section>

      <section>
        <div className="container-site py-16 md:py-20">
          <form onSubmit={handleSubmit} className="card-soft mx-auto max-w-3xl md:p-8">
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label htmlFor="patientName" className="field-label">
                  Patient/Client Name *
                </label>
                <input
                  id="patientName"
                  required
                  maxLength={100}
                  value={form.patientName}
                  onChange={(e) => set("patientName", e.target.value)}
                  className="field-input"
                  placeholder="Full name of the person needing care"
                />
              </div>
              <div>
                <label htmlFor="contactPerson" className="field-label">
                  Contact Person
                </label>
                <input
                  id="contactPerson"
                  maxLength={100}
                  value={form.contactPerson}
                  onChange={(e) => set("contactPerson", e.target.value)}
                  className="field-input"
                  placeholder="If different from the patient"
                />
              </div>
              <div>
                <label htmlFor="phone" className="field-label">
                  Phone Number *
                </label>
                <input
                  id="phone"
                  required
                  type="tel"
                  maxLength={20}
                  value={form.phone}
                  onChange={(e) => set("phone", e.target.value)}
                  className="field-input"
                  placeholder="+254 ..."
                />
              </div>
              <div>
                <label htmlFor="location" className="field-label">
                  Location *
                </label>
                <input
                  id="location"
                  required
                  maxLength={120}
                  value={form.location}
                  onChange={(e) => set("location", e.target.value)}
                  className="field-input"
                  placeholder="e.g. Kilimani, Nairobi"
                />
              </div>
              <div>
                <label htmlFor="preferredDate" className="field-label">
                  Preferred Date *
                </label>
                <input
                  id="preferredDate"
                  required
                  type="date"
                  value={form.preferredDate}
                  onChange={(e) => set("preferredDate", e.target.value)}
                  className="field-input"
                />
              </div>
              <div>
                <label htmlFor="preferredTime" className="field-label">
                  Preferred Time
                </label>
                <input
                  id="preferredTime"
                  type="time"
                  value={form.preferredTime}
                  onChange={(e) => set("preferredTime", e.target.value)}
                  className="field-input"
                />
              </div>
              <div>
                <label htmlFor="service" className="field-label">
                  Service Required *
                </label>
                <select
                  id="service"
                  required
                  value={form.service}
                  onChange={(e) => set("service", e.target.value)}
                  className="field-input"
                >
                  {SERVICES.map((s) => (
                    <option key={s.title} value={s.title}>
                      {s.title}
                    </option>
                  ))}
                  <option value="Other / Not sure yet">Other / Not sure yet</option>
                </select>
              </div>
              <div>
                <label htmlFor="contactMethod" className="field-label">
                  Preferred Contact Method
                </label>
                <select
                  id="contactMethod"
                  value={form.contactMethod}
                  onChange={(e) => set("contactMethod", e.target.value)}
                  className="field-input"
                >
                  {contactMethods.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="description" className="field-label">
                  Brief Description of Care Needed *
                </label>
                <textarea
                  id="description"
                  required
                  maxLength={1000}
                  rows={4}
                  value={form.description}
                  onChange={(e) => set("description", e.target.value)}
                  className="field-input resize-none"
                  placeholder="Tell me briefly about the patient's situation and the kind of support you're looking for..."
                />
              </div>
              <div className="sm:col-span-2">
                <label className="flex items-start gap-3 text-sm text-muted-foreground">
                  <input
                    type="checkbox"
                    required
                    checked={form.consent}
                    onChange={(e) => set("consent", e.target.checked)}
                    className="mt-0.5 size-4 shrink-0 accent-[var(--color-primary)]"
                  />
                  <span>
                    I consent to {SITE.businessName} contacting me using the details provided to
                    discuss this request. *
                  </span>
                </label>
              </div>
            </div>
            <button type="submit" className="btn-primary mt-7 w-full">
              <CalendarCheck className="size-4" />
              Request Home Visit
            </button>
            <p className="mt-3 text-center text-xs leading-relaxed text-muted-foreground">
              Submitting this form is a request only and does not automatically constitute a
              confirmed appointment. Prefer to write instead?{" "}
              <a
                href={`mailto:${SITE.email}?subject=${encodeURIComponent("Home nursing visit request")}`}
                className="font-medium text-primary hover:underline"
              >
                Email Clinton
              </a>
              .
            </p>
            <a
              href={whatsappHref()}
              target="_blank"
              rel="noreferrer"
              className="btn-whatsapp mt-4 w-full"
            >
              <MessageCircle className="size-4" />
              Or chat directly on WhatsApp
            </a>
          </form>
        </div>
      </section>
    </div>
  );
}
