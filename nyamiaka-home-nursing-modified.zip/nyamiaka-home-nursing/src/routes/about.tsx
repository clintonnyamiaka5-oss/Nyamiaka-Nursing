import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  ClipboardList,
  GraduationCap,
  MessagesSquare,
  ShieldCheck,
  Stethoscope,
  UserRoundCheck,
} from "lucide-react";

import heroNurse from "@/assets/hero-nurse.jpg";
import homeAssessment from "@/assets/home-assessment.jpg";
import { SITE } from "@/lib/site";

export const Route = createFileRoute("/about")({
  component: AboutPage,
  head: () => ({
    meta: [
      { title: `About — ${SITE.founder} | ${SITE.businessName}` },
      {
        name: "description",
        content:
          "Meet Clinton G. Nyamiaka, BScN — a Bachelor of Science in Nursing graduate of Amref International University providing professional nurse-led home-based care in Nairobi, Kenya.",
      },
      { property: "og:title", content: `About — ${SITE.founder}` },
      {
        property: "og:description",
        content:
          "Education, professional background and nursing approach of Clinton G. Nyamiaka, BScN — nurse-led home-based care in Nairobi.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const approach = [
  {
    icon: UserRoundCheck,
    title: "Patient-Centered Care",
    text: "Care is tailored to the individual patient and their specific needs.",
  },
  {
    icon: Stethoscope,
    title: "Clinical Professionalism",
    text: "Nursing services are provided according to appropriate professional standards and within the nurse's scope of practice.",
  },
  {
    icon: ShieldCheck,
    title: "Patient Dignity",
    text: "Every patient receives respectful, confidential and compassionate care.",
  },
  {
    icon: GraduationCap,
    title: "Health Education",
    text: "Patients and caregivers receive practical information that helps them participate in their own care.",
  },
  {
    icon: ClipboardList,
    title: "Early Recognition & Referral",
    text: "Changes in a patient's condition are recognized appropriately, with referral to a higher level of care when necessary.",
  },
];

const experience = [
  {
    org: "Amref Health Africa / Amref International University",
    role: "Nursing Internship / Nursing Skills Training Support",
    detail:
      "Department of Nursing and Midwifery. Hands-on clinical exposure and support of nursing skills training within the department.",
  },
  {
    org: "AMIU Nursing Students Association",
    role: "Former Chairperson",
    detail:
      "Leadership experience demonstrating deep involvement in nursing education, student leadership and professional development.",
  },
  {
    org: "KESNNUR Nairobi Regional Committee",
    role: "Organising Secretary",
    detail:
      "Professional leadership and organizational experience within the nursing community.",
  },
];

function AboutPage() {
  return (
    <div>
      <section className="bg-surface-soft">
        <div className="container-site grid items-center gap-12 py-16 md:grid-cols-12 md:py-20">
          <div className="md:col-span-7">
            <p className="section-eyebrow">Meet your nurse</p>
            <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
              {SITE.founder}
            </h1>
            <p className="mt-6 max-w-[56ch] text-base leading-relaxed text-pretty text-muted-foreground">
              Clinton G. Nyamiaka is a Bachelor of Science in Nursing graduate from Amref
              International University. His professional interests include patient-centered
              nursing care, health education, clinical skills development and bringing appropriate
              healthcare support closer to patients and families.
            </p>
          </div>
          <div className="md:col-span-5">
            <div className="relative">
              <div className="absolute -inset-3 -z-10 rounded-3xl bg-card ring-1 ring-border" />
              <img
                src={heroNurse}
                alt="Clinton G. Nyamiaka, BScN — professional nurse"
                width={1024}
                height={1024}
                loading="lazy"
                className="aspect-4/5 w-full rounded-2xl object-cover ring-1 ring-border"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Education & registration */}
      <section>
        <div className="container-site grid gap-6 py-16 md:grid-cols-2 md:py-20">
          <div className="card-soft md:p-8">
            <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
              <GraduationCap className="size-5" strokeWidth={1.7} />
            </span>
            <h2 className="mt-4 font-display text-2xl font-semibold tracking-tight">Education</h2>
            <dl className="mt-4 space-y-1.5 text-sm">
              <div>
                <dt className="font-semibold text-foreground">
                  Bachelor of Science in Nursing (BScN)
                </dt>
                <dd className="text-muted-foreground">
                  Amref International University (AMIU)
                </dd>
                <dd className="text-muted-foreground">Nairobi, Kenya</dd>
              </div>
            </dl>
          </div>
          <div className="card-soft md:p-8">
            <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
              <ShieldCheck className="size-5" strokeWidth={1.7} />
            </span>
            <h2 className="mt-4 font-display text-2xl font-semibold tracking-tight">
              Professional Registration
            </h2>
            <p className="mt-4 rounded-xl bg-surface-soft px-4 py-3 text-sm font-medium text-muted-foreground ring-1 ring-border">
              [Insert verified NCK registration/licensing details]
            </p>
          </div>
        </div>
      </section>

      {/* Professional background */}
      <section className="border-t border-border bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <div className="max-w-[52ch]">
            <p className="section-eyebrow">Professional background</p>
            <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Nursing &amp; Professional Experience
            </h2>
          </div>
          <div className="mt-10 space-y-4">
            {experience.map((item) => (
              <div key={item.org} className="card-soft md:p-8">
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">
                  {item.org}
                </p>
                <h3 className="mt-2 font-display text-xl font-semibold tracking-tight">
                  {item.role}
                </h3>
                <p className="mt-2 max-w-[72ch] text-sm leading-relaxed text-pretty text-muted-foreground">
                  {item.detail}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Approach */}
      <section>
        <div className="container-site py-16 md:py-20">
          <div className="max-w-[52ch]">
            <p className="section-eyebrow">Professional approach</p>
            <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Nursing Care With Purpose
            </h2>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {approach.map((item) => (
              <div key={item.title} className="card-soft">
                <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
                  <item.icon className="size-5" strokeWidth={1.7} />
                </span>
                <h3 className="mt-4 font-display text-lg font-semibold tracking-tight">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-pretty text-muted-foreground">
                  {item.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Credentials */}
      <section className="border-t border-border bg-surface-soft">
        <div className="container-site grid items-center gap-10 py-16 md:grid-cols-12 md:py-20">
          <div className="md:col-span-5">
            <img
              src={homeAssessment}
              alt="Professional nursing assessment at home"
              width={1024}
              height={1024}
              loading="lazy"
              className="aspect-4/5 w-full rounded-3xl object-cover ring-1 ring-border"
            />
          </div>
          <div className="md:col-span-7">
            <p className="section-eyebrow">Professional credentials</p>
            <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              {SITE.founder}
            </h2>
            <div className="mt-6 space-y-4 text-sm">
              <div className="card-soft">
                <p className="font-semibold text-foreground">Bachelor of Science in Nursing</p>
                <p className="mt-1 text-muted-foreground">Amref International University</p>
              </div>
              <div className="card-soft">
                <p className="font-semibold text-foreground">Professional Registration</p>
                <p className="mt-1 text-muted-foreground">
                  [Insert verified NCK registration/licensing information]
                </p>
              </div>
              <div className="card-soft">
                <p className="font-semibold text-foreground">Additional Certifications</p>
                <p className="mt-1 text-muted-foreground">[Add verified certifications]</p>
              </div>
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/book" className="btn-primary">
                Book a Home Visit
                <ArrowRight className="size-4" />
              </Link>
              <Link to="/services" className="btn-secondary">
                <MessagesSquare className="size-4" />
                View services
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
