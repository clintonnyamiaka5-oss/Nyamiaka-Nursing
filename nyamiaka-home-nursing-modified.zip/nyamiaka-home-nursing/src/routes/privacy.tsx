import { createFileRoute } from "@tanstack/react-router";
import { SITE } from "@/lib/site";

export const Route = createFileRoute("/privacy")({
  component: PrivacyPage,
  head: () => ({
    meta: [
      { title: `Privacy Policy — ${SITE.businessName}` },
      {
        name: "description",
        content:
          "How Nyamiaka Home Nursing & Care collects, uses and protects patient and client information.",
      },
      { property: "og:title", content: `Privacy Policy — ${SITE.businessName}` },
      {
        property: "og:description",
        content: "How your personal and health information is handled and protected.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function PrivacyPage() {
  return (
    <div>
      <section className="bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <p className="section-eyebrow">Legal</p>
          <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
            Privacy Policy
          </h1>
        </div>
      </section>
      <section>
        <div className="container-site max-w-3xl space-y-8 py-16 md:py-20">
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              1. Information we collect
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              When you contact {SITE.businessName} or submit a booking request, we collect the
              information you choose to share: names, phone numbers, email addresses, location and
              a brief description of the care needed. Health-related information is collected only
              where necessary to assess whether home nursing support is appropriate.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              2. How we use your information
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              Your information is used to respond to your enquiry, plan and provide nursing care,
              communicate with you and, where relevant, coordinate with other healthcare providers
              involved in the patient's care with your consent.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              3. Confidentiality
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              All patient information is treated as confidential. Health information is not sold,
              shared or used for marketing, and is only disclosed where required by law or with
              the patient's (or their guardian's) consent.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              4. Data retention & security
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              Records are kept only as long as necessary for the provision of care and any legal
              or professional documentation requirements. Reasonable safeguards are used to
              protect your information from unauthorised access.
            </p>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold tracking-tight">
              5. Your rights & contact
            </h2>
            <p className="mt-3 text-sm leading-relaxed text-pretty text-muted-foreground">
              You may ask what information we hold about you, request a correction, or withdraw
              consent to be contacted at any time. For any privacy question, contact{" "}
              {SITE.founder} at{" "}
              <a
                href={`mailto:${SITE.email}`}
                className="font-medium text-primary hover:underline"
              >
                {SITE.email}
              </a>{" "}
              or call {SITE.phoneDisplay}.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
