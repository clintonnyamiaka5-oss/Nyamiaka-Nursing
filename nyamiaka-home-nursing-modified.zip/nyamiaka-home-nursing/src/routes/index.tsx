import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  CalendarCheck,
  ClipboardList,
  GraduationCap,
  HandHeart,
  HeartPulse,
  Home,
  Lock,
  MessageCircle,
  Phone,
  ShieldCheck,
  Stethoscope,
  UserRound,
} from "lucide-react";

import heroNurse from "@/assets/hero-nurse.jpg";
import homeAssessment from "@/assets/home-assessment.jpg";
import { SITE, whatsappHref, DEFAULT_WHATSAPP_MESSAGE, SERVICES } from "@/lib/site";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: `${SITE.businessName} — ${SITE.tagline}` },
      {
        name: "description",
        content:
          "Professional, nurse-led home-based healthcare in Nairobi, Kenya — nursing visits, wound care, health monitoring, postnatal and elderly support by Clinton G. Nyamiaka, BScN.",
      },
      { property: "og:title", content: `${SITE.businessName} — ${SITE.tagline}` },
      {
        property: "og:description",
        content:
          "Personalized, compassionate and professional nursing support delivered to patients and families in the comfort and privacy of their homes.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

const whyChoose = [
  {
    icon: GraduationCap,
    title: "Qualified Nursing Professional",
    text: "Care led by a BScN-qualified nurse.",
  },
  {
    icon: UserRound,
    title: "Personalized Care",
    text: "Support designed around the individual patient's needs.",
  },
  {
    icon: Stethoscope,
    title: "Professional Approach",
    text: "Care delivered with clinical responsibility and respect for professional scope.",
  },
  {
    icon: Home,
    title: "Convenient Home Visits",
    text: "Appropriate nursing support delivered within the patient's home environment.",
  },
  {
    icon: ClipboardList,
    title: "Patient & Family Education",
    text: "Helping patients and caregivers understand their care.",
  },
  {
    icon: Lock,
    title: "Confidential & Dignified",
    text: "Respecting patient privacy, dignity and confidentiality.",
  },
];

const steps = [
  {
    num: "01",
    title: "Contact",
    text: "Call, WhatsApp or submit a home-visit request.",
  },
  {
    num: "02",
    title: "Discuss",
    text: "Briefly discuss the patient's needs and determine whether home nursing support is appropriate.",
  },
  {
    num: "03",
    title: "Home Assessment",
    text: "Attend the scheduled visit and conduct an appropriate nursing assessment.",
  },
  {
    num: "04",
    title: "Care & Follow-Up",
    text: "Provide appropriate nursing care, health education, follow-up or referral according to the patient's needs.",
  },
];

function Index() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-surface-soft">
        <div className="container-site grid items-center gap-12 py-16 md:grid-cols-12 md:py-24">
          <div className="md:col-span-7">
            <p className="mb-5 inline-flex items-center gap-2 rounded-full bg-card px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-primary ring-1 ring-border">
              <HeartPulse className="size-3.5" />
              Nurse-led home-based care · Nairobi, Kenya
            </p>
            <h1 className="font-display text-4xl font-semibold leading-tight tracking-tight text-balance sm:text-5xl md:text-6xl">
              Professional Nursing Care, Right in the Comfort of Your Home.
            </h1>
            <p className="mt-6 max-w-[52ch] text-base leading-relaxed text-pretty text-muted-foreground md:text-lg">
              Personalized, compassionate and professional nursing support delivered to patients
              and families in the comfort and privacy of their homes.
            </p>
            <p className="mt-4 font-display text-lg font-semibold text-foreground">
              {SITE.founder}
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link to="/book" className="btn-primary">
                <CalendarCheck className="size-4" />
                Book a Home Visit
              </Link>
              <a href={SITE.phoneHref} className="btn-secondary">
                <Phone className="size-4" />
                Call the Nurse
              </a>
              <a
                href={whatsappHref(DEFAULT_WHATSAPP_MESSAGE)}
                target="_blank"
                rel="noreferrer"
                className="btn-whatsapp"
              >
                <MessageCircle className="size-4" />
                WhatsApp the Nurse
              </a>
            </div>
          </div>
          <div className="md:col-span-5">
            <div className="relative">
              <div className="absolute -inset-3 -z-10 rounded-3xl bg-card ring-1 ring-border" />
              <img
                src={heroNurse}
                alt="Clinton G. Nyamiaka, BScN — professional nurse"
                width={1024}
                height={1024}
                className="aspect-4/5 w-full rounded-2xl object-cover ring-1 ring-border"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Meet your nurse */}
      <section>
        <div className="container-site grid items-center gap-10 py-16 md:grid-cols-12 md:py-20">
          <div className="md:col-span-5">
            <img
              src={homeAssessment}
              alt="Professional nurse conducting a home-based patient assessment"
              width={1024}
              height={1024}
              loading="lazy"
              className="aspect-4/5 w-full rounded-3xl object-cover ring-1 ring-border"
            />
          </div>
          <div className="md:col-span-7">
            <p className="section-eyebrow">Meet your nurse</p>
            <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              {SITE.founder}
            </h2>
            <p className="mt-5 max-w-[56ch] text-base leading-relaxed text-pretty text-muted-foreground">
              Clinton G. Nyamiaka is a Bachelor of Science in Nursing graduate from Amref
              International University. His professional interests include patient-centered
              nursing care, health education, clinical skills development and bringing appropriate
              healthcare support closer to patients and families.
            </p>
            <div className="mt-8">
              <Link
                to="/about"
                className="inline-flex items-center gap-2 text-sm font-semibold text-primary transition-colors hover:text-primary-deep"
              >
                More about Clinton
                <ArrowRight className="size-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Trust strip */}
      <section className="border-y border-border bg-background">
        <div className="container-site grid gap-0 py-2 sm:grid-cols-3">
          <div className="flex items-center gap-3 px-2 py-3 sm:border-r sm:border-border">
            <GraduationCap className="size-5 shrink-0 text-primary" />
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.12em] text-primary">Qualified</p>
              <p className="text-sm text-muted-foreground">BScN nurse-led service</p>
            </div>
          </div>
          <div className="flex items-center gap-3 border-t border-border px-2 py-3 sm:border-t-0 sm:border-r">
            <ShieldCheck className="size-5 shrink-0 text-primary" />
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.12em] text-primary">Professional</p>
              <p className="text-sm text-muted-foreground">Confidential &amp; patient-centred</p>
            </div>
          </div>
          <div className="flex items-center gap-3 border-t border-border px-2 py-3 sm:border-t-0">
            <Home className="size-5 shrink-0 text-primary" />
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.12em] text-primary">Convenient</p>
              <p className="text-sm text-muted-foreground">Planned home visits in Nairobi</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services preview */}
      <section className="border-t border-border bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <div className="max-w-[52ch]">
            <p className="section-eyebrow">Home nursing services</p>
            <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Appropriate, professional support — at home.
            </h2>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.slice(0, 6).map((service) => (
              <div key={service.title} className="card-soft">
                <h3 className="font-display text-lg font-semibold tracking-tight">
                  {service.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-pretty text-muted-foreground">
                  {service.text}
                </p>
              </div>
            ))}
          </div>
          <div className="mt-8">
            <Link to="/services" className="btn-secondary">
              View all services
              <ArrowRight className="size-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Clinical positioning */}
      <section>
        <div className="container-site py-16 md:py-20">
          <div className="rounded-3xl bg-primary px-6 py-12 text-center text-primary-foreground md:px-14">
            <Stethoscope className="mx-auto size-8" />
            <h2 className="mx-auto mt-5 max-w-[26ch] font-display text-3xl font-semibold leading-tight text-balance sm:text-4xl">
              This is professional nurse-led care — not simply caregiving.
            </h2>
            <p className="mx-auto mt-5 max-w-[64ch] text-sm leading-relaxed text-pretty text-primary-foreground/85 md:text-base">
              {SITE.businessName} is designed to provide appropriate professional nursing support
              within the home environment while recognizing when a patient requires assessment or
              treatment at a hospital, clinic or other appropriate healthcare facility.
            </p>
          </div>
        </div>
      </section>

      {/* Why choose */}
      <section className="border-t border-border bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <div className="max-w-[52ch]">
            <p className="section-eyebrow">Why choose us</p>
            <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              Why choose {SITE.businessName}?
            </h2>
          </div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {whyChoose.map((item) => (
              <div key={item.title} className="card-soft">
                <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
                  <item.icon className="size-5" strokeWidth={1.7} />
                </span>
                <h3 className="mt-4 font-display text-lg font-semibold tracking-tight">
                  {item.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-pretty text-muted-foreground">
                  {item.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section>
        <div className="container-site py-16 md:py-20">
          <div className="max-w-[52ch]">
            <p className="section-eyebrow">How it works</p>
            <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
              From first call to ongoing care.
            </h2>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-4">
            {steps.map((step) => (
              <div key={step.num} className="card-soft">
                <span className="font-display text-3xl font-semibold text-primary/40">
                  {step.num}
                </span>
                <h3 className="mt-3 font-display text-lg font-semibold tracking-tight">
                  {step.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-pretty text-muted-foreground">
                  {step.text}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="border-t border-border bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <div className="grid items-center gap-10 md:grid-cols-12">
            <div className="md:col-span-7">
              <h2 className="font-display text-3xl font-semibold leading-tight tracking-tight text-balance sm:text-4xl">
                Need professional nursing care at home?
              </h2>
              <p className="mt-4 max-w-[50ch] text-base leading-relaxed text-pretty text-muted-foreground">
                Whether you are recovering at home, caring for an elderly family member or looking
                for professional nursing support, get in touch to discuss your needs.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/book" className="btn-primary">
                  Book a Home Visit
                </Link>
                <a href={SITE.phoneHref} className="btn-secondary">
                  Call the Nurse
                </a>
                <a
                  href={whatsappHref(DEFAULT_WHATSAPP_MESSAGE)}
                  target="_blank"
                  rel="noreferrer"
                  className="btn-whatsapp"
                >
                  WhatsApp Clinton
                </a>
              </div>
              <div className="mt-8 flex flex-wrap gap-x-8 gap-y-2 text-sm text-muted-foreground">
                <span className="flex items-center gap-2">
                  <ShieldCheck className="size-4 text-primary" />
                  {SITE.founder}
                </span>
                <span className="flex items-center gap-2">
                  <HandHeart className="size-4 text-primary" />
                  {SITE.phoneDisplay}
                </span>
              </div>
            </div>
            <div className="md:col-span-5">
              <img
                src={heroNurse}
                alt="Clinton G. Nyamiaka, BScN"
                width={1024}
                height={1024}
                loading="lazy"
                className="aspect-4/5 w-full rounded-3xl object-cover ring-1 ring-border"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
