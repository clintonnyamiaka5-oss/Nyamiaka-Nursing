import { createFileRoute, Link } from "@tanstack/react-router";
import { Mail, MapPin, MessageCircle, Phone } from "lucide-react";

import { SITE, whatsappHref, DEFAULT_WHATSAPP_MESSAGE } from "@/lib/site";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: `Contact — ${SITE.businessName}` },
      {
        name: "description",
        content:
          "Call 0757 669 961, email clintonnyamiaka5@gmail.com or WhatsApp Clinton G. Nyamiaka, BScN for professional home nursing care in Nairobi, Kenya.",
      },
      { property: "og:title", content: `Contact — ${SITE.businessName}` },
      {
        property: "og:description",
        content:
          "Get in touch for professional nurse-led home-based care in Nairobi — call, email or WhatsApp Clinton directly.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
});

function ContactPage() {
  return (
    <div>
      <section className="bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <p className="section-eyebrow">Contact</p>
          <h1 className="mt-3 max-w-[26ch] font-display text-4xl font-semibold tracking-tight text-balance sm:text-5xl">
            Get in touch with your nurse.
          </h1>
          <p className="mt-5 max-w-[52ch] text-base leading-relaxed text-pretty text-muted-foreground md:text-lg">
            Whether you are recovering at home, caring for an elderly family member or looking for
            professional nursing support, get in touch to discuss your needs.
          </p>
        </div>
      </section>

      <section>
        <div className="container-site grid gap-6 py-16 md:grid-cols-3 md:py-20">
          <a
            href={SITE.phoneHref}
            className="card-soft flex flex-col gap-4 transition-colors hover:bg-secondary"
          >
            <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
              <Phone className="size-5" strokeWidth={1.7} />
            </span>
            <span>
              <span className="block font-display text-lg font-semibold">CALL {SITE.phoneDisplay}</span>
              <span className="mt-1 block text-sm text-muted-foreground">
                Call Clinton directly to discuss your needs.
              </span>
            </span>
          </a>
          <a
            href={`mailto:${SITE.email}`}
            className="card-soft flex flex-col gap-4 transition-colors hover:bg-secondary"
          >
            <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
              <Mail className="size-5" strokeWidth={1.7} />
            </span>
            <span className="min-w-0">
              <span className="block font-display text-lg font-semibold">EMAIL CLINTON</span>
              <span className="mt-1 block truncate text-sm text-muted-foreground">
                {SITE.email}
              </span>
            </span>
          </a>
          <a
            href={whatsappHref(DEFAULT_WHATSAPP_MESSAGE)}
            target="_blank"
            rel="noreferrer"
            className="card-soft flex flex-col gap-4 transition-colors hover:bg-secondary"
          >
            <span className="grid size-11 place-items-center rounded-xl bg-primary/10 text-primary">
              <MessageCircle className="size-5" strokeWidth={1.7} />
            </span>
            <span>
              <span className="block font-display text-lg font-semibold">WHATSAPP THE NURSE</span>
              <span className="mt-1 block text-sm text-muted-foreground">
                Message {SITE.phoneDisplay} on WhatsApp.
              </span>
            </span>
          </a>
        </div>
      </section>

      {/* Areas served */}
      <section className="border-t border-border bg-surface-soft">
        <div className="container-site py-16 md:py-20">
          <p className="section-eyebrow">Service location</p>
          <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
            Areas We Serve
          </h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="card-soft flex items-center gap-4">
              <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
                <MapPin className="size-5" strokeWidth={1.7} />
              </span>
              <span>
                <span className="block font-display text-lg font-semibold">{SITE.area}</span>
                <span className="block text-sm text-muted-foreground">
                  Currently serving — get in touch to confirm your location.
                </span>
              </span>
            </div>
            <div className="card-soft flex items-center gap-4 opacity-70">
              <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-muted text-muted-foreground">
                <MapPin className="size-5" strokeWidth={1.7} />
              </span>
              <span>
                <span className="block font-display text-lg font-semibold text-muted-foreground">
                  [Additional area]
                </span>
                <span className="block text-sm text-muted-foreground">
                  Space reserved as the service expands.
                </span>
              </span>
            </div>
            <div className="card-soft flex items-center gap-4 opacity-70">
              <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-muted text-muted-foreground">
                <MapPin className="size-5" strokeWidth={1.7} />
              </span>
              <span>
                <span className="block font-display text-lg font-semibold text-muted-foreground">
                  [Additional area]
                </span>
                <span className="block text-sm text-muted-foreground">
                  Space reserved as the service expands.
                </span>
              </span>
            </div>
          </div>
          <div className="mt-10 flex flex-wrap gap-3">
            <Link to="/book" className="btn-primary">
              Book a Home Visit
            </Link>
            <a href={SITE.phoneHref} className="btn-secondary">
              Call the Nurse
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
