import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";
import { MessageCircle, Phone, Siren } from "lucide-react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { SITE } from "@/lib/site";

function NotFoundComponent() {
  return (
    <div className="flex min-h-[60vh] items-center justify-center px-4">
      <div className="max-w-md text-center">
        <h1 className="font-display text-7xl font-semibold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link to="/" className="btn-primary">
            Back home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-[60vh] items-center justify-center px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="btn-primary"
          >
            Try again
          </button>
          <a href="/" className="btn-secondary">
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: `${SITE.businessName} — ${SITE.tagline}` },
      {
        name: "description",
        content:
          "Nurse-led home-based healthcare in Nairobi, Kenya. Professional nursing care, health education, monitoring and support — delivered at home by Clinton G. Nyamiaka, BScN.",
      },
      { property: "og:site_name", content: SITE.businessName },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;0,9..144,700;1,9..144,500&family=Inter:wght@400;500;600;700&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

const navLinks = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/services", label: "Services" },
  { to: "/book", label: "Book a Visit" },
  { to: "/contact", label: "Contact" },
] as const;

const activeLinkClass = "rounded-full px-3 py-2 text-sm font-semibold text-primary bg-secondary";
const idleLinkClass =
  "rounded-full px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground";

function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="container-site grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 py-3 sm:flex sm:justify-between sm:py-4">
        <Link to="/" className="flex min-w-0 items-center gap-3">
          <span className="grid size-10 shrink-0 place-items-center rounded-full bg-primary font-display text-lg font-semibold text-primary-foreground">
            N
          </span>
          <span className="min-w-0">
            <span className="block truncate font-display text-base font-semibold leading-tight text-foreground sm:text-lg">
              {SITE.businessName}
            </span>
            <span className="block truncate text-[10px] font-medium uppercase tracking-[0.14em] text-primary">
              {SITE.tagline}
            </span>
          </span>
        </Link>
        <nav className="flex shrink-0 items-center gap-1">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`${idleLinkClass} hidden md:block`}
              activeProps={{ className: `${activeLinkClass} hidden md:block` }}
            >
              {link.label}
            </Link>
          ))}
          <a
            href={SITE.phoneHref}
            aria-label={`Call ${SITE.businessName}`}
            className="hidden rounded-full p-2 text-primary transition-colors hover:bg-secondary sm:inline-flex md:hidden"
          >
            <Phone className="size-5" />
          </a>
          <Link
            to="/book"
            className="ml-1 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary-deep"
          >
            Book a visit
          </Link>
        </nav>
      </div>
    </header>
  );
}

function EmergencyStrip() {
  return (
    <div className="border-b border-border bg-accent/40">
      <div className="container-site flex flex-col items-start gap-2 py-3 text-xs text-accent-foreground sm:flex-row sm:items-center sm:justify-between">
        <p className="flex items-center gap-2 font-medium">
          <Siren className="size-4 shrink-0 text-destructive" />
          <span>
            <strong>Medical emergency?</strong> This is a planned home-visiting service, not an
            emergency response service. For life-threatening conditions, seek immediate emergency
            medical care.
          </span>
        </p>
        <a
          href={SITE.emergencyNumberHref}
          className="shrink-0 rounded-full bg-destructive px-4 py-1.5 text-xs font-semibold text-destructive-foreground transition-opacity hover:opacity-90"
        >
          Seek emergency care ({SITE.emergencyNumberDisplay})
        </a>
      </div>
    </div>
  );
}

function MobileActionBar() {
  return (
    <div className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-background/95 p-2 shadow-[0_-8px_30px_rgba(0,0,0,0.08)] backdrop-blur-md md:hidden">
      <div className="mx-auto grid max-w-lg grid-cols-3 gap-2">
        <a href={SITE.phoneHref} className="mobile-action">
          <Phone className="size-4" />
          Call
        </a>
        <a
          href={whatsappHref(DEFAULT_WHATSAPP_MESSAGE)}
          target="_blank"
          rel="noreferrer"
          className="mobile-action mobile-action-whatsapp"
        >
          <MessageCircle className="size-4" />
          WhatsApp
        </a>
        <Link to="/book" className="mobile-action mobile-action-primary">
          <CalendarCheckIcon />
          Book
        </Link>
      </div>
    </div>
  );
}

function CalendarCheckIcon() {
  return <span className="text-sm leading-none" aria-hidden="true">✓</span>;
}

function SiteFooter() {
  return (
    <footer>
      <EmergencyStrip />
      <div className="border-t border-border bg-surface-soft">
        <div className="container-site grid gap-10 py-12 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-3">
              <span className="grid size-10 place-items-center rounded-full bg-primary font-display text-lg font-semibold text-primary-foreground">
                N
              </span>
              <div>
                <p className="font-display text-base font-semibold text-foreground">
                  {SITE.businessName}
                </p>
                <p className="text-xs text-muted-foreground">{SITE.tagline}</p>
              </div>
            </div>
            <p className="mt-4 max-w-[36ch] text-sm leading-relaxed text-muted-foreground">
              {SITE.secondaryMessage}
            </p>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">
              Explore
            </p>
            <nav className="mt-4 flex flex-col gap-2 text-sm">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className="w-fit text-muted-foreground transition-colors hover:text-primary"
                >
                  {link.label}
                </Link>
              ))}
              <Link
                to="/privacy"
                className="w-fit text-muted-foreground transition-colors hover:text-primary"
              >
                Privacy Policy
              </Link>
              <Link
                to="/terms"
                className="w-fit text-muted-foreground transition-colors hover:text-primary"
              >
                Terms
              </Link>
            </nav>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.14em] text-primary">
              Contact
            </p>
            <div className="mt-4 space-y-2 text-sm text-muted-foreground">
              <p className="font-semibold text-foreground">{SITE.founder}</p>
              <p>{SITE.base}</p>
              <p>
                Phone:{" "}
                <a href={SITE.phoneHref} className="font-medium text-primary hover:underline">
                  {SITE.phoneDisplay}
                </a>
              </p>
              <p>
                Email:{" "}
                <a
                  href={`mailto:${SITE.email}`}
                  className="font-medium break-all text-primary hover:underline"
                >
                  {SITE.email}
                </a>
              </p>
            </div>
          </div>
        </div>
        <div className="border-t border-border">
          <div className="container-site py-5 text-center text-xs text-muted-foreground">
            © {new Date().getFullYear()} {SITE.businessName}. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      <div className="flex min-h-screen flex-col">
        <SiteHeader />
        <main className="flex-1">
          {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
          <Outlet />
        </main>
        <SiteFooter />
        <MobileActionBar />
      </div>
    </QueryClientProvider>
  );
}
