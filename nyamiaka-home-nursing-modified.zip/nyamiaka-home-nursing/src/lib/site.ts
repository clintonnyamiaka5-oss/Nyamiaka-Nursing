// Shared site data — edit these values in one place.

export const SITE = {
  businessName: "Nyamiaka Home Nursing & Care",
  founder: "Clinton G. Nyamiaka, BScN",
  tagline: "Professional Nursing Care. Right at Your Doorstep.",
  secondaryMessage:
    "Quality nursing care, delivered with professionalism, dignity and compassion.",
  phoneDisplay: "0757 669 961",
  phoneHref: "tel:+254757669961",
  whatsappNumber: "254757669961",
  email: "clintonnyamiaka5@gmail.com",
  base: "Amref International University, Nairobi, Kenya",
  area: "Nairobi, Kenya",
  emergencyNumberDisplay: "999",
  emergencyNumberHref: "tel:999",
};

export function whatsappHref(message?: string) {
  const base = `https://wa.me/${SITE.whatsappNumber}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export const DEFAULT_WHATSAPP_MESSAGE =
  "Hello Clinton, I would like to request a home nursing visit.";

export const SERVICES = [
  {
    title: "Home Nursing Visits",
    text: "Professional nursing assessment, monitoring, education and appropriate nursing interventions in the home environment.",
  },
  {
    title: "Wound & Dressing Care",
    text: "Appropriate wound assessment, dressing and monitoring according to the patient's condition and care requirements.",
  },
  {
    title: "Post-Hospitalization Nursing Support",
    text: "Nursing support for patients transitioning from hospital back to the comfort of their home.",
  },
  {
    title: "Vital Signs & Health Monitoring",
    text: "Monitoring of blood pressure, pulse, temperature, respiratory rate, oxygen saturation and other appropriate parameters.",
  },
  {
    title: "Medication Support",
    text: "Medication-related nursing support and administration where appropriate and within professional scope.",
  },
  {
    title: "Elderly Nursing Support",
    text: "Professional nursing support and health monitoring for older adults requiring assistance at home.",
  },
  {
    title: "Chronic Disease Support",
    text: "Nursing monitoring, education and support for patients living with chronic conditions, alongside their established medical care.",
  },
  {
    title: "Maternal & Postnatal Support",
    text: "Appropriate nursing support and health education during the postnatal period, with referral where complications or concerns are identified.",
  },
  {
    title: "Caregiver Education",
    text: "Practical education and guidance for family members and caregivers involved in patient care.",
  },
  {
    title: "Health Education",
    text: "Education on medication adherence, hygiene, prevention of complications, healthy practices and appropriate healthcare-seeking.",
  },
] as const;
